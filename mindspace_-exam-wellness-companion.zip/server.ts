import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint for analyzing journal entries
  app.post("/api/analyze", async (req, res) => {
    try {
      const { journalEntry, mood } = req.body;
      const customKey = req.headers['x-gemini-api-key'] as string | undefined;

      const apiKey = customKey || process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.status(401).json({ error: "No API key found. Please provide one in settings or configure GEMINI_API_KEY." });
      }

      if (!journalEntry) {
        return res.status(400).json({ error: "Missing journalEntry" });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const prompt = `
        Analyze the following journal entry and mood from a student studying for high-stakes exams.
        Current Mood: ${mood || 'Not specified'}
        Journal Entry: "${journalEntry}"
        
        Provide structured insights. Identify hidden stress triggers and emotional patterns.
        Then generate a hyper-personalized wellness toolkit containing adaptive mindfulness exercises and tailored motivational encouragement.
      `;

      let response;
      try {
        response = await ai.models.generateContent({
          model: "gemini-3.1-pro-preview",
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
            systemInstruction: "You are an empathetic, always-available digital companion prioritizing student safety, confidence-building, and healthy study habits. Ensure your tone remains supportive, non-judgmental, and encouraging.",
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                triggers: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of hidden stress triggers identified."
                },
                patterns: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of emotional patterns or burnout themes detected."
                },
                exercises: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: "Name of the mindfulness exercise." },
                      steps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Steps to perform the exercise." }
                    },
                    required: ["name", "steps"]
                  },
                  description: "Adaptive mindfulness exercises."
                },
                motivation: {
                  type: Type.STRING,
                  description: "A tailored, empathetic motivational message acting as a digital mentor."
                }
              },
              required: ["triggers", "patterns", "exercises", "motivation"]
            }
          }
        });
      } catch (proError: any) {
        console.warn("Gemini 3.1 Pro failed or hit quota limits, falling back to Gemini 3.5 Flash:", proError.message || proError);
        response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            systemInstruction: "You are an empathetic, always-available digital companion prioritizing student safety, confidence-building, and healthy study habits. Ensure your tone remains supportive, non-judgmental, and encouraging.",
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                triggers: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of hidden stress triggers identified."
                },
                patterns: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of emotional patterns or burnout themes detected."
                },
                exercises: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: "Name of the mindfulness exercise." },
                      steps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Steps to perform the exercise." }
                    },
                    required: ["name", "steps"]
                  },
                  description: "Adaptive mindfulness exercises."
                },
                motivation: {
                  type: Type.STRING,
                  description: "A tailored, empathetic motivational message acting as a digital mentor."
                }
              },
              required: ["triggers", "patterns", "exercises", "motivation"]
            }
          }
        });
      }

      const text = response.text;
      if (!text) throw new Error("No text returned from Gemini");

      res.json(JSON.parse(text));
    } catch (error: any) {
      console.error("Error calling Gemini API:", error);
      res.status(500).json({ error: error.message || "Failed to analyze journal entry." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve static files from dist
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
