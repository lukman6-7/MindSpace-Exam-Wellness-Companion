import { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Sun, Moon } from 'lucide-react';
import { SettingsPanel } from './components/SettingsPanel';
import { JournalForm } from './components/JournalForm';
import { InsightsDashboard } from './components/InsightsDashboard';
import { TrendChart } from './components/TrendChart';
import { WeeklySummary } from './components/WeeklySummary';
import { PomodoroTimer } from './components/PomodoroTimer';
import { AnalyzerResponse, HistoryItem } from './types';

const SEED_HISTORY: HistoryItem[] = [
  {
    id: 'seed-1',
    date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'burnout',
    entry: 'Studied for 14 hours straight. My head is spinning, cannot retain anything. NEET syllabus is vast.',
    wellbeingScore: 0,
  },
  {
    id: 'seed-2',
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'overwhelmed',
    entry: 'Woke up feeling anxious. Tested low on Physics mock test. Formulae feel completely mixed up.',
    wellbeingScore: 1,
  },
  {
    id: 'seed-3',
    date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'exhausted',
    entry: 'Took a small walk, tried 4-7-8 breathing. Sleep pattern is poor but a bit more oxygenated.',
    wellbeingScore: 3,
  },
  {
    id: 'seed-4',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'anxious',
    entry: 'Solving Chemistry equations. Still worried about accuracy but trying to focus on one chapter/time.',
    wellbeingScore: 2,
  },
  {
    id: 'seed-5',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'okay',
    entry: 'Better. Solved some previous years papers calmly. Feeling average but staying grounded.',
    wellbeingScore: 4,
  },
  {
    id: 'seed-6',
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    mood: 'focused',
    entry: 'Reviewed all summary notes. Feeling a good momentum. Keeping positive intentions!',
    wellbeingScore: 5,
  }
];

const getMoodScore = (mood: string): number => {
  const scores: Record<string, number> = {
    focused: 5,
    okay: 4,
    exhausted: 3,
    anxious: 2,
    overwhelmed: 1,
    burnout: 0
  };
  return scores[mood] ?? 3;
};

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('mindspace_theme') as 'light' | 'dark') || 'light';
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('mindspace_api_key') || '');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [insights, setInsights] = useState<AnalyzerResponse | null>(null);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('mindspace_theme', nextTheme);
  };
  
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const raw = localStorage.getItem('mindspace_session_history');
    return raw ? JSON.parse(raw) : SEED_HISTORY; // Default seed to make it stunning out of the box!
  });

  const handleApiKeyChange = (key: string) => {
    setApiKey(key);
    localStorage.setItem('mindspace_api_key', key);
  };

  const handleAnalyze = async (journalEntry: string, mood: string) => {
    setIsLoading(true);
    setError(null);
    setInsights(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      if (apiKey.trim()) {
        headers['x-gemini-api-key'] = apiKey.trim();
      }

      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers,
        body: JSON.stringify({ journalEntry, mood }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to analyze journal entry');
      }

      setInsights(data);

      const newItem: HistoryItem = {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
        date: new Date().toISOString(),
        mood: mood || 'okay',
        entry: journalEntry,
        wellbeingScore: getMoodScore(mood),
      };

      setHistory(prev => {
        const updated = [...prev, newItem];
        localStorage.setItem('mindspace_session_history', JSON.stringify(updated));
        return updated;
      });
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.setItem('mindspace_session_history', JSON.stringify([]));
  };

  const handleSeedHistory = () => {
    setHistory(SEED_HISTORY);
    localStorage.setItem('mindspace_session_history', JSON.stringify(SEED_HISTORY));
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#080c14] text-slate-800 dark:text-slate-100 relative selection:bg-purple-200 dark:selection:bg-purple-900 transition-colors duration-300">
      {/* Decorative calm background blobs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-[500px] w-[500px] rounded-full bg-purple-200/40 dark:bg-purple-900/10 mix-blend-multiply dark:mix-blend-screen blur-[100px]" />
        <div className="absolute -right-20 top-40 h-[400px] w-[400px] rounded-full bg-emerald-200/40 dark:bg-emerald-900/10 mix-blend-multiply dark:mix-blend-screen blur-[100px]" />
        <div className="absolute bottom-0 left-1/2 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-blue-100/40 dark:bg-blue-900/10 mix-blend-multiply dark:mix-blend-screen blur-[100px]" />
      </div>
 
      <header className="relative flex items-center justify-between px-6 py-6 sm:px-12">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-500 text-white shadow-sm">
            <span className="font-display text-xl font-bold">M</span>
          </div>
          <h1 className="font-display text-xl font-medium tracking-tight text-slate-800 dark:text-slate-100">
            MindSpace
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            className="rounded-full bg-white/60 dark:bg-slate-850/60 p-2.5 text-slate-500 dark:text-slate-400 shadow-sm backdrop-blur-md ring-1 ring-white/60 dark:ring-slate-700/60 transition-all hover:bg-white dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 focus:outline-none focus:ring-4 focus:ring-purple-100"
          >
            {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </button>
          <button
            onClick={() => setIsSettingsOpen(true)}
            title="API Configuration Settings"
            className="rounded-full bg-white/60 dark:bg-slate-850/60 p-2.5 text-slate-500 dark:text-slate-400 shadow-sm backdrop-blur-md ring-1 ring-white/60 dark:ring-slate-700/60 transition-all hover:bg-white dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 focus:outline-none focus:ring-4 focus:ring-purple-100"
          >
            <SettingsIcon className="h-5 w-5" />
          </button>
        </div>
      </header>
 
      <main className="relative mx-auto max-w-7xl px-4 pb-24 pt-8 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-display text-4xl font-medium tracking-tight text-slate-800 dark:text-slate-100 sm:text-5xl">
            Exam Wellness Companion
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-slate-500 dark:text-slate-400">
            High-stakes exams don't have to break you. Dump your thoughts, clear your mind, 
            and let's find your balance together.
          </p>
        </div>

        {error && (
          <div className="mx-auto mb-8 max-w-2xl rounded-2xl bg-red-50 p-4 text-center text-sm text-red-600 ring-1 ring-red-200">
            {error}
          </div>
        )}

        <JournalForm onSubmit={handleAnalyze} isLoading={isLoading} />
        
        <PomodoroTimer />
        
        <TrendChart history={history} onClearHistory={handleClearHistory} onSeedHistory={handleSeedHistory} />
        
        <WeeklySummary history={history} />
        
        <InsightsDashboard data={insights} />
      </main>

      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        apiKey={apiKey}
        setApiKey={handleApiKeyChange}
      />
    </div>
  );
}
