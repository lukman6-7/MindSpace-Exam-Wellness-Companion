export interface AnalyzerResponse {
  triggers: string[];
  patterns: string[];
  exercises: {
    name: string;
    steps: string[];
  }[];
  motivation: string;
}

export interface HistoryItem {
  id: string;
  date: string;
  mood: string;
  entry: string;
  wellbeingScore: number;
}
