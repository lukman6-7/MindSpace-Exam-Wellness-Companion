import { motion } from 'motion/react';
import { Award, Target, Landmark, Calendar, Sparkles } from 'lucide-react';
import { HistoryItem } from '../types';

interface WeeklySummaryProps {
  history: HistoryItem[];
}

const MOOD_META: Record<string, { label: string; verb: string; color: string; val: number }> = {
  focused: { label: 'Focused 🎯', verb: 'unbelievable lock-in and productivity', color: 'text-blue-600 bg-blue-50 ring-blue-100', val: 5 },
  okay: { label: 'Okay 🍀', verb: 'reassuring stability and daily balance', color: 'text-emerald-600 bg-emerald-50 ring-emerald-100', val: 4 },
  exhausted: { label: 'Exhausted 🔋', verb: 'brave perseverance despite extreme physical limits', color: 'text-slate-600 bg-slate-50 ring-slate-100', val: 3 },
  anxious: { label: 'Anxious 🌪️', verb: 'weathering exam anticipation with high resilience', color: 'text-orange-600 bg-orange-50 ring-orange-200', val: 2 },
  overwhelmed: { label: 'Overwhelmed 🌊', verb: 'navigating strong tides of pressure with grit', color: 'text-purple-600 bg-purple-50 ring-purple-100', val: 1 },
  burnout: { label: 'Burnout 🔥', verb: 'prioritizing safety and rest after pushing yourself to the absolute limit', color: 'text-red-600 bg-red-50 ring-red-100', val: 0 },
};

export function WeeklySummary({ history }: WeeklySummaryProps) {
  if (history.length === 0) return null;

  // Let's analyze historical stats for the physical mock tests / preparations
  const activeMoodsCount = history.reduce((acc, item) => {
    acc[item.mood] = (acc[item.mood] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedMoods = Object.entries(activeMoodsCount).sort((a, b) => b[1] - a[1]);
  const topMood = sortedMoods[0]?.[0] || 'okay';
  const topMoodMeta = MOOD_META[topMood];

  // Consistency multiplier
  const weeklyStreak = history.filter(item => {
    const diff = Date.now() - new Date(item.date).getTime();
    return diff <= 7 * 24 * 60 * 60 * 1000;
  }).length;

  // Emphathetic messages based on level of engagement
  let celebratoryMessage = '';
  let advice = '';

  if (weeklyStreak >= 5) {
    celebratoryMessage = "You have unlocked the 'Sustained Resilience' milestone! Writing down your thoughts regularly during mock season is a hallmark of top performers.";
    advice = "Your high self-awareness is your superpower. Remember to honor micro-breaks. You are doing beautiful work, digital companion is incredibly proud of your system.";
  } else if (weeklyStreak >= 3) {
    celebratoryMessage = "Sustained momentum! You connected with yourself on multiple days this week to release heavy exam loads.";
    advice = "Try setting a non-negotiable bedtime ritual tonight to help lower systemic study tension.";
  } else {
    celebratoryMessage = "Splendid attempt! Every entry matters, even the quiet singular reflections.";
    advice = "No matter the results of mock tests, you are valued for who you are, not just your rank. Be extraordinarily gentle with yourself today.";
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto mt-8 w-full max-w-4xl overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Award className="h-5 w-5 text-purple-600 dark:text-purple-400" />
          <h2 className="font-display text-xl font-medium text-slate-800 dark:text-slate-100">MindSpace Weekly Reflection</h2>
        </div>
        <span className="rounded-full bg-indigo-50 dark:bg-indigo-950/40 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-indigo-600 dark:text-indigo-400 font-semibold ring-1 ring-indigo-100 dark:ring-indigo-900/40">
          7-Day Review
        </span>
      </div>

      <div className="grid gap-6 md:grid-cols-12">
        <div className="md:col-span-4 flex flex-col justify-between rounded-2xl bg-gradient-to-br from-purple-100/30 to-indigo-100/30 dark:from-purple-950/20 dark:to-indigo-950/20 p-5 ring-1 ring-purple-100/50 dark:ring-purple-900/30">
          <div>
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wide">Top Emotional Mode</span>
            {topMoodMeta ? (
              <div className="mt-2.5">
                <p className="font-display text-2xl font-semibold text-slate-800 dark:text-slate-100 capitalize">
                  {topMoodMeta.label}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                  Reflects <span className="font-medium text-purple-700 dark:text-purple-400">{topMoodMeta.verb}</span>.
                </p>
              </div>
            ) : (
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 font-semibold">Ready to assess</p>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-purple-200/20 dark:border-purple-900/20 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <span className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
              This Week's Activity
            </span>
            <span className="font-semibold text-xs text-purple-700 dark:text-purple-400">{weeklyStreak} times logged</span>
          </div>
        </div>

        <div className="md:col-span-8 flex flex-col justify-center space-y-4">
          <div className="relative overflow-hidden rounded-2xl bg-white/40 dark:bg-slate-950/20 p-5 ring-1 ring-slate-100 dark:ring-slate-800/40">
            <div className="absolute top-0 right-0 h-16 w-16 -translate-y-4 translate-x-4 rounded-full bg-purple-200/10 dark:bg-purple-900/5 blur-xl" />
            <div className="flex gap-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-50 dark:bg-amber-950/45 text-amber-600 dark:text-amber-400 ring-1 ring-amber-100 dark:ring-amber-900/30">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <h4 className="font-display text-sm font-semibold text-slate-700 dark:text-slate-200">Insight & Celebration</h4>
                <p className="text-sm text-slate-600 dark:text-slate-350 leading-relaxed mt-1.5">{celebratoryMessage}</p>
              </div>
            </div>
          </div>

          <div className="flex gap-3 overflow-hidden rounded-2xl bg-emerald-50/20 dark:bg-emerald-950/10 p-5 ring-1 ring-emerald-100/30 dark:ring-emerald-900/20">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-50 dark:bg-emerald-950/45 text-emerald-600 dark:text-emerald-400 ring-1 ring-emerald-100 dark:ring-emerald-900/30">
              <Target className="h-4 w-4" />
            </div>
            <div>
              <h4 className="font-display text-sm font-semibold text-slate-700 dark:text-slate-200">Supportive Mentorship Guidelines</h4>
              <p className="text-sm text-slate-600 dark:text-slate-350 leading-relaxed mt-1.5">{advice}</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
