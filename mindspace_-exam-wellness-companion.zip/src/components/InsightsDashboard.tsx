import { motion } from 'motion/react';
import { Target, Activity, Heart, ArrowRight } from 'lucide-react';
import { AnalyzerResponse } from '../types';

interface InsightsDashboardProps {
  data: AnalyzerResponse | null;
}

export function InsightsDashboard({ data }: InsightsDashboardProps) {
  if (!data) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto mt-8 w-full max-w-4xl space-y-6"
    >
      <div className="overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-100 dark:bg-purple-950/45 text-purple-600 dark:text-purple-400">
            <Heart className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-display text-xl font-medium text-slate-800 dark:text-slate-100">Your Digital Mentor</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">A tailored message just for you.</p>
          </div>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-purple-50/50 to-indigo-50/50 dark:from-purple-950/20 dark:to-indigo-950/20 p-6 ring-1 ring-purple-100/50 dark:ring-purple-900/30">
          <p className="text-lg leading-relaxed text-slate-700 dark:text-slate-200 italic">" {data.motivation} "</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-100 dark:bg-orange-950/45 text-orange-600 dark:text-orange-400">
              <Target className="h-5 w-5" />
            </div>
            <h3 className="font-display text-lg font-medium text-slate-800 dark:text-slate-100">Hidden Stress Triggers</h3>
          </div>
          <ul className="space-y-3">
            {data.triggers.map((trigger, i) => (
              <motion.li
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                key={i}
                className="flex items-start gap-3 rounded-xl bg-orange-50/50 dark:bg-orange-950/15 p-3 text-sm text-slate-700 dark:text-slate-300 ring-1 ring-orange-100/50 dark:ring-orange-900/20"
              >
                <div className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-orange-400 dark:bg-orange-500" />
                <span>{trigger}</span>
              </motion.li>
            ))}
            {data.triggers.length === 0 && <p className="text-sm text-slate-500 dark:text-slate-400">No specific triggers detected.</p>}
          </ul>
        </div>

        <div className="overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-950/45 text-blue-600 dark:text-blue-400">
              <Activity className="h-5 w-5" />
            </div>
            <h3 className="font-display text-lg font-medium text-slate-800 dark:text-slate-100">Emotional Patterns</h3>
          </div>
          <ul className="space-y-3">
            {data.patterns.map((pattern, i) => (
              <motion.li
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                key={i}
                className="flex items-start gap-3 rounded-xl bg-blue-50/50 dark:bg-blue-950/15 p-3 text-sm text-slate-700 dark:text-slate-300 ring-1 ring-blue-100/50 dark:ring-blue-900/20"
              >
                <div className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-400 dark:bg-blue-500" />
                <span>{pattern}</span>
              </motion.li>
            ))}
            {data.patterns.length === 0 && <p className="text-sm text-slate-500 dark:text-slate-400">No specific patterns detected.</p>}
          </ul>
        </div>
      </div>

      <div className="overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8">
        <div className="mb-6">
          <h2 className="font-display text-xl font-medium text-slate-800 dark:text-slate-100">Personalized Wellness Toolkit</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Adaptive mindfulness exercises based on your state of mind.</p>
        </div>
        
        <div className="grid gap-4 sm:grid-cols-2">
          {data.exercises.map((exercise, i) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.15 }}
              key={i}
              className="flex flex-col rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/10 p-5 ring-1 ring-emerald-100/50 dark:ring-emerald-900/20"
            >
              <h4 className="mb-3 font-display font-medium text-emerald-800 dark:text-emerald-300">{exercise.name}</h4>
              <ul className="space-y-2">
                {exercise.steps.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-350">
                    <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
