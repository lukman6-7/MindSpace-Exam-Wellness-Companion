import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { HistoryItem } from '../types';
import { Calendar, Trash2, RotateCcw, TrendingUp, Sparkles, Search, Filter, Clock } from 'lucide-react';

interface TrendChartProps {
  history: HistoryItem[];
  onClearHistory: () => void;
  onSeedHistory: () => void;
}

const MOOD_META: Record<string, { label: string; color: string; val: number }> = {
  focused: { label: 'Focused 🎯', color: '#3b82f6', val: 5 },
  okay: { label: 'Okay 🍀', color: '#10b981', val: 4 },
  exhausted: { label: 'Exhausted 🔋', color: '#64748b', val: 3 },
  anxious: { label: 'Anxious 🌪️', color: '#f97316', val: 2 },
  overwhelmed: { label: 'Overwhelmed 🌊', color: '#a855f7', val: 1 },
  burnout: { label: 'Burnout 🔥', color: '#ef4444', val: 0 },
};

export function TrendChart({ history, onClearHistory, onSeedHistory }: TrendChartProps) {
  const [viewCount, setViewCount] = useState<number>(7);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMoodFilter, setSelectedMoodFilter] = useState<string>('');

  const sortedData = [...history]
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const chartData = sortedData.slice(-viewCount).map(item => ({
    ...item,
    formattedDate: new Date(item.date).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
    }),
    moodLabel: MOOD_META[item.mood]?.label || item.mood,
    wellbeingScore: item.wellbeingScore,
  }));

  const activeMoodsCount = history.reduce((acc, item) => {
    acc[item.mood] = (acc[item.mood] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const dominantMood = Object.entries(activeMoodsCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'Okay';

  // Filtered history (latest first)
  const filteredHistory = [...history]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .filter(item => {
      const matchesSearch = item.entry.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesMood = selectedMoodFilter ? item.mood === selectedMoodFilter : true;
      return matchesSearch && matchesMood;
    });

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="rounded-xl border border-slate-100 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-3.5 shadow-lg backdrop-blur-md">
          <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
            {new Date(data.date).toLocaleDateString(undefined, { 
              weekday: 'short', 
              month: 'long', 
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </p>
          <p className="mt-1 font-display text-sm font-medium text-slate-800 dark:text-slate-100">
            Mood: <span className="font-semibold">{MOOD_META[data.mood]?.label || data.mood}</span>
          </p>
          <p className="mt-1 max-w-[240px] truncate text-xs text-slate-500 dark:text-slate-400 italic">
            "{data.entry}"
          </p>
          <div className="mt-2.5 flex items-center gap-1.5 border-t border-slate-100 dark:border-slate-800 pt-2 font-display text-xs text-slate-600 dark:text-slate-400">
            <span className="font-medium text-purple-600 dark:text-purple-400">Wellbeing Matrix: </span>
            {data.wellbeingScore} / 5
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="mx-auto mt-8 w-full max-w-4xl overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-purple-500 dark:text-purple-400" />
            <h2 className="font-display text-xl font-medium text-slate-800 dark:text-slate-100">Emotional Well-being Trend</h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">Track your mental state changes over mock cycles and milestones.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setViewCount(7)}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-medium transition-all ${
              viewCount === 7
                ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300'
                : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Last 7 Entries
          </button>
          <button
            onClick={() => setViewCount(15)}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-medium transition-all ${
              viewCount === 15
                ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300'
                : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Last 15
          </button>
          <button
            onClick={() => setViewCount(999)}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-medium transition-all ${
              viewCount === 999
                ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300'
                : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            All Logs
          </button>
        </div>
      </div>

      {history.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Calendar className="h-12 w-12 text-slate-300 dark:text-slate-700 animate-pulse" />
          <h3 className="mt-4 font-display text-base font-medium text-slate-700 dark:text-slate-300">No Mood Trend Logs Yet</h3>
          <p className="mt-1 max-w-sm text-xs text-slate-400 dark:text-slate-500">
            Submit your first MindSpace journal brain-dump above to automatically begin tracking your trend over time.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={onSeedHistory}
              className="flex items-center gap-2 rounded-xl bg-purple-50 dark:bg-purple-950/20 px-4 py-2 text-xs font-medium text-purple-700 dark:text-purple-300 ring-1 ring-purple-100 dark:ring-purple-900/30 transition-all hover:bg-purple-100 dark:hover:bg-purple-900/40"
            >
              <Sparkles className="h-3.5 w-3.5 text-purple-500 dark:text-purple-400" />
              <span>Use Simulated Stress Journey</span>
            </button>
          </div>
        </div>
      ) : (
        <div>
          {/* Quick Stats Panel */}
          <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
            <div className="rounded-2xl bg-slate-50/50 dark:bg-slate-950/20 p-4 ring-1 ring-slate-100 dark:ring-slate-800/40">
              <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">Total MindSpace Entries</span>
              <p className="mt-1 font-display text-2xl font-semibold text-slate-700 dark:text-slate-200">{history.length}</p>
            </div>
            <div className="rounded-2xl bg-slate-50/50 dark:bg-slate-950/20 p-4 ring-1 ring-slate-100 dark:ring-slate-800/40">
              <span className="text-xs text-slate-400 dark:text-slate-550 font-medium">Dominant Emotional Tone</span>
              <p className="mt-1 font-display text-sm font-semibold capitalize text-slate-700 dark:text-slate-200 animate-pulse">
                {MOOD_META[dominantMood]?.label || dominantMood}
              </p>
            </div>
            <div className="col-span-2 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20 p-4 ring-1 ring-slate-100 dark:ring-slate-800/40 sm:col-span-1 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 dark:text-slate-550 font-medium">History Actions</span>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">Clear details or re-seed data.</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={onSeedHistory}
                  title="Simulate / Re-seed mock stress points"
                  className="rounded-xl p-2 text-slate-400 dark:text-slate-500 hover:bg-purple-100 dark:hover:bg-purple-950/40 hover:text-purple-600 dark:hover:text-purple-400 transition-all"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
                <button
                  onClick={onClearHistory}
                  title="Clear history completely"
                  className="rounded-xl p-2 text-slate-400 dark:text-slate-500 hover:bg-red-50 dark:hover:bg-red-950/20 hover:text-red-500 dark:hover:text-red-400 transition-all"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          <div className="h-80 w-full rounded-2xl bg-gradient-to-r from-slate-50/20 to-slate-50/5 dark:from-slate-950/10 dark:to-slate-950/5 p-4 ring-1 ring-slate-100 dark:ring-slate-800/40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="wellbeingGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.01}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(148, 163, 184, 0.1)" />
                <XAxis 
                  dataKey="formattedDate" 
                  tickLine={false}
                  axisLine={false}
                  tick={{ fill: '#94a3b8', fontSize: 11 }}
                />
                <YAxis 
                  domain={[0, 5]} 
                  ticks={[0, 1, 2, 3, 4, 5]}
                  tickFormatter={(val) => {
                    if (val === 5) return 'Focused';
                    if (val === 4) return 'Okay';
                    if (val === 2) return 'Anxious';
                    if (val === 0) return 'Burnout';
                    return '';
                  }}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fill: '#94a3b8', fontSize: 11 }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="wellbeingScore" 
                  stroke="#a855f7" 
                  strokeWidth={2.5}
                  fillOpacity={1} 
                  fill="url(#wellbeingGrad)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Search Table & Filters Section */}
          <div className="mt-8 border-t border-slate-100 dark:border-slate-850 pt-8">
            <div className="mb-6">
              <h3 className="font-display text-lg font-medium text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Search className="h-4 w-4 text-purple-500 dark:text-purple-400" />
                <span>Reflect & Filter Past Logs</span>
              </h3>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Search through your emotional dumps and mental notes over your preparation journey.</p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
                <input
                  type="text"
                  placeholder="Search journals (e.g., 'mock test', 'physics')..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-xl border border-slate-200/50 dark:border-slate-800 bg-white/50 dark:bg-slate-950/40 pl-10 pr-4 py-2 text-sm text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:border-purple-300 dark:focus:border-purple-800 focus:outline-none focus:ring-4 focus:ring-purple-100/50 dark:focus:ring-purple-950/50"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs font-medium text-slate-400 dark:text-slate-500 flex items-center gap-1 mr-1">
                  <Filter className="h-3 w-3" /> Filter:
                </span>
                <button
                  onClick={() => setSelectedMoodFilter('')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
                    selectedMoodFilter === ''
                      ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300'
                      : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100/80 dark:hover:bg-slate-800'
                  }`}
                >
                  All
                </button>
                {Object.keys(MOOD_META).map(key => (
                  <button
                    key={key}
                    onClick={() => setSelectedMoodFilter(key)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
                      selectedMoodFilter === key
                        ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300'
                        : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100/80 dark:hover:bg-slate-800'
                    }`}
                  >
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Filtered History */}
            <div className="mt-6 space-y-3.5 max-h-[350px] overflow-y-auto pr-1 scrollbar-thin">
              {filteredHistory.length === 0 ? (
                <div className="text-center py-8 bg-slate-50/50 dark:bg-slate-950/20 rounded-2xl ring-1 ring-slate-100 dark:ring-slate-800/40">
                  <p className="text-sm text-slate-400 dark:text-slate-500">No logs match your search terms or filter.</p>
                </div>
              ) : (
                filteredHistory.map((item) => (
                  <div key={item.id} className="rounded-2xl bg-white/40 dark:bg-slate-950/10 p-4 ring-1 ring-slate-100/80 dark:ring-slate-800/30 hover:bg-white/80 dark:hover:bg-slate-950/30 transition-all flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <span className="text-xs font-medium text-slate-700 dark:text-slate-350 bg-slate-100/80 dark:bg-slate-900/50 px-2 py-0.5 rounded-md flex items-center gap-1 shrink-0">
                          <Clock className="h-3 w-3 text-slate-400 dark:text-slate-500" />
                          {new Date(item.date).toLocaleDateString(undefined, { 
                            month: 'short', 
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 shrink-0">
                          {MOOD_META[item.mood]?.label || item.mood}
                        </span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 shrink-0">
                          Wellbeing: {item.wellbeingScore}/5
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-sans">{item.entry}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
