import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, BookOpen, AlertCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function PomodoroTimer() {
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [customBreakTime, setCustomBreakTime] = useState(5);
  const [customWorkTime, setCustomWorkTime] = useState(25);
  const [completedSessions, setCompletedSessions] = useState(() => {
    return Number(localStorage.getItem('mindspace_completed_sessions') || '0');
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Sound effect alternative (using Web Audio API to play comforting ambient chime so no external assets are required)
  const playComfortChime = () => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      
      // Gentle chime with two frequencies
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(659.25, ctx.currentTime); // E5

      gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 1.2);
      osc2.stop(ctx.currentTime + 1.2);
    } catch (e) {
      console.warn("Audio playback not supported or interaction limit", e);
    }
  };

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            playComfortChime();
            if (!isBreak) {
              setCompletedSessions(prev => {
                const updated = prev + 1;
                localStorage.setItem('mindspace_completed_sessions', String(updated));
                return updated;
              });
              setIsBreak(true);
              return customBreakTime * 60;
            } else {
              setIsBreak(false);
              return customWorkTime * 60;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, isBreak, customWorkTime, customBreakTime]);

  const handleToggle = () => {
    setIsActive(!isActive);
  };

  const handleReset = () => {
    setIsActive(false);
    setIsBreak(false);
    setSecondsLeft(customWorkTime * 60);
  };

  const handleSetIntervals = (work: number, breakTime: number) => {
    setIsActive(false);
    setIsBreak(false);
    setCustomWorkTime(work);
    setCustomBreakTime(breakTime);
    setSecondsLeft(work * 60);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  // Safe outer perimeter visual styling percentage for progress circle
  const currentTotalTime = isBreak ? customBreakTime * 60 : customWorkTime * 60;
  const progressPercent = ((currentTotalTime - secondsLeft) / currentTotalTime) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto mt-8 w-full max-w-2xl overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8"
    >
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Timer controls */}
        <div className="flex-1 w-full space-y-4">
          <div className="flex items-center gap-2">
            {isBreak ? (
              <Coffee className="h-5 w-5 text-emerald-500 animate-pulse" />
            ) : (
              <BookOpen className="h-5 w-5 text-purple-500" />
            )}
            <h2 className="font-display text-xl font-medium text-slate-800 dark:text-slate-100">
              {isBreak ? 'Time to Recharge' : 'Focused Deep Work Session'}
            </h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {isBreak 
              ? 'Stand up, grab some warm tea, stretch, or practice 4-7-8 breathing now.' 
              : 'Close secondary social tabs. Focus single-mindedly on your targets.'
            }
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-2">
            <button
              onClick={() => handleSetIntervals(25, 5)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold tracking-wide transition-all ${
                customWorkTime === 25 && customBreakTime === 5
                  ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold'
                  : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Classic (25m / 5m)
            </button>
            <button
              onClick={() => handleSetIntervals(50, 10)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold tracking-wide transition-all ${
                customWorkTime === 50 && customBreakTime === 10
                  ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold'
                  : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              UPSC/JEE Deep Cycle (50m / 10m)
            </button>
            <button
              onClick={() => handleSetIntervals(15, 3)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold tracking-wide transition-all ${
                customWorkTime === 15 && customBreakTime === 3
                  ? 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold'
                  : 'bg-white/50 dark:bg-slate-800/25 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Micro-Sprint (15m / 3m)
            </button>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-800/50">
            <div className="rounded-xl bg-purple-50/50 dark:bg-purple-950/20 p-3 ring-1 ring-purple-100/30 dark:ring-purple-900/20 flex items-center gap-2 flex-grow sm:flex-grow-0">
              <Sparkles className="h-4 w-4 text-purple-500" />
              <div className="text-left">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">Study Endurance Cycles Done</p>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">{completedSessions} fully completed</p>
              </div>
            </div>
            {completedSessions > 0 && (
              <button
                onClick={() => {
                  setCompletedSessions(0);
                  localStorage.setItem('mindspace_completed_sessions', '0');
                }}
                className="text-xs text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 transition-all font-medium"
              >
                Reset Total Tracker
              </button>
            )}
          </div>
        </div>

        {/* Visual Timer circle */}
        <div className="relative shrink-0 flex items-center justify-center h-44 w-44">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="88"
              cy="88"
              r="76"
              className="stroke-slate-100 dark:stroke-slate-800/50"
              strokeWidth="6"
              fill="transparent"
            />
            <circle
              cx="88"
              cy="88"
              r="76"
              className={`transition-all duration-300 ${isBreak ? 'stroke-emerald-400' : 'stroke-purple-400'}`}
              strokeWidth="6"
              fill="transparent"
              strokeDasharray={477.5}
              strokeDashoffset={477.5 - (477.5 * progressPercent) / 100}
              strokeLinecap="round"
            />
          </svg>

          <div className="absolute flex flex-col items-center justify-center">
            <span className="font-display text-3xl font-bold tracking-tight text-slate-800 dark:text-slate-100">
              {formatTime(secondsLeft)}
            </span>
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-slate-500 mt-1">
              {isBreak ? 'Break' : 'Study'}
            </span>
            
            <div className="flex items-center gap-2 mt-3.5">
              <button
                onClick={handleToggle}
                className={`p-2 rounded-full transition-all text-white ${
                  isActive 
                    ? 'bg-amber-500 hover:bg-amber-600 shadow-md shadow-amber-100' 
                    : 'bg-purple-600 hover:bg-purple-700 shadow-md shadow-purple-100'
                }`}
              >
                {isActive ? <Pause className="h-3.5 w-3.5 fill-current" /> : <Play className="h-3.5 w-3.5 fill-current ml-0.5" />}
              </button>
              <button
                onClick={handleReset}
                className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-all"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
