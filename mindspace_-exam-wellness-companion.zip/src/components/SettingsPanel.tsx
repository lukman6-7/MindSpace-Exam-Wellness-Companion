import { Settings, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  setApiKey: (key: string) => void;
}

export function SettingsPanel({ isOpen, onClose, apiKey, setApiKey }: SettingsPanelProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="relative w-full max-w-md overflow-hidden rounded-2xl bg-white/80 dark:bg-slate-900/80 p-6 shadow-xl backdrop-blur-xl ring-1 ring-white/50 dark:ring-slate-800/50"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2 text-slate-800 dark:text-slate-100">
                <Settings className="h-5 w-5" />
                <h2 className="font-display text-xl font-medium tracking-tight">Settings</h2>
              </div>
              <button
                onClick={onClose}
                className="rounded-full p-2 text-slate-400 dark:text-slate-500 transition-colors hover:bg-slate-100/50 dark:hover:bg-slate-800/50 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="apiKey" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">
                  Gemini API Key (Optional)
                </label>
                <input
                  id="apiKey"
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API key..."
                  className="w-full rounded-xl border border-slate-200/50 dark:border-slate-800 bg-white/50 dark:bg-slate-950/40 px-4 py-2 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 shadow-sm backdrop-blur-sm transition-all focus:border-purple-300 dark:focus:border-purple-800 focus:outline-none focus:ring-4 focus:ring-purple-100/50 dark:focus:ring-purple-950/50"
                />
                <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                  By default, MindSpace uses the securely integrated cloud key. 
                  Provide your own key here only if you wish to override the default. 
                  Your key is sent securely to our proxy and never hits Gemini directly from the browser.
                </p>
              </div>
            </div>

            <div className="mt-8 flex justify-end">
              <button
                onClick={onClose}
                className="rounded-xl bg-purple-100 dark:bg-purple-950/40 px-5 py-2 text-sm font-medium text-purple-700 dark:text-purple-350 transition-all hover:bg-purple-200 dark:hover:bg-purple-900/40 focus:outline-none focus:ring-4 focus:ring-purple-50 dark:focus:ring-purple-900"
              >
                Done
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
