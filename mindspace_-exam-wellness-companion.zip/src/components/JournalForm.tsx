import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Frown, Meh, Smile, Battery, BatteryWarning, Wind, Mic, MicOff, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface JournalFormProps {
  onSubmit: (journalEntry: string, mood: string) => void;
  isLoading: boolean;
}

const MOODS = [
  { id: 'anxious', label: 'Anxious', icon: Wind, color: 'text-orange-500 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-950/20 hover:bg-orange-100 dark:hover:bg-orange-900/20 ring-orange-200 dark:ring-orange-950/50' },
  { id: 'burnout', label: 'Burnout', icon: BatteryWarning, color: 'text-red-500 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-950/20 hover:bg-red-100 dark:hover:bg-red-900/20 ring-red-200 dark:ring-red-950/50' },
  { id: 'exhausted', label: 'Exhausted', icon: Battery, color: 'text-slate-500 dark:text-slate-400', bg: 'bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800/60 ring-slate-200 dark:ring-slate-800/50' },
  { id: 'overwhelmed', label: 'Overwhelmed', icon: Frown, color: 'text-purple-500 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-950/20 hover:bg-purple-100 dark:hover:bg-purple-900/20 ring-purple-200 dark:ring-purple-950/50' },
  { id: 'okay', label: 'Okay', icon: Meh, color: 'text-emerald-500 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/20 hover:bg-emerald-100 dark:hover:bg-emerald-900/20 ring-emerald-200 dark:ring-emerald-950/50' },
  { id: 'focused', label: 'Focused', icon: Smile, color: 'text-blue-500 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-950/20 hover:bg-blue-100 dark:hover:bg-blue-900/20 ring-blue-200 dark:ring-blue-950/50' },
];

export function JournalForm({ onSubmit, isLoading }: JournalFormProps) {
  const [entry, setEntry] = useState('');
  const [selectedMood, setSelectedMood] = useState<string>('');
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechSupported(true);
    }
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      setSpeechError(null);
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListening(true);
      };

      rec.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setEntry(prev => {
            const spacer = prev && !prev.endsWith(' ') ? ' ' : '';
            return prev + spacer + finalTranscript;
          });
        }
      };

      rec.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        if (event.error === 'not-allowed') {
          setSpeechError('Microphone permission is required. Please allow access in browser settings.');
        } else {
          setSpeechError(`Voice input issue: ${event.error}`);
        }
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
      rec.start();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entry.trim() || isLoading) return;
    onSubmit(entry, selectedMood);
  };

  return (
    <motion.form 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto w-full max-w-2xl overflow-hidden rounded-3xl bg-white/60 dark:bg-slate-900/40 p-6 shadow-sm backdrop-blur-xl ring-1 ring-white/60 dark:ring-slate-800/40 sm:p-8"
      onSubmit={handleSubmit}
    >
      <div className="mb-8">
        <label className="mb-3 block font-display text-lg font-medium text-slate-800 dark:text-slate-100">
          How are you feeling right now?
        </label>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
          {MOODS.map((mood) => {
            const Icon = mood.icon;
            const isSelected = selectedMood === mood.id;
            return (
              <button
                key={mood.id}
                type="button"
                onClick={() => setSelectedMood(mood.id)}
                className={`flex flex-col items-center justify-center gap-2 rounded-2xl p-3 transition-all ${
                  isSelected 
                    ? `${mood.bg} ${mood.color} ring-2 scale-105 shadow-sm` 
                    : 'bg-white/50 dark:bg-slate-800/20 text-slate-400 dark:text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/40 hover:text-slate-600 dark:hover:text-slate-300 ring-1 ring-slate-100 dark:ring-slate-800/40'
                }`}
              >
                <Icon className="h-6 w-6" />
                <span className="text-xs font-medium">{mood.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <label htmlFor="journal" className="block font-display text-lg font-medium text-slate-800 dark:text-slate-100">
            Brain-Dump Your Thoughts
          </label>
          {speechSupported && (
            <button
              type="button"
              onClick={toggleListening}
              className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition-all focus:outline-none focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900 ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-100'
                  : 'bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 text-purple-700 dark:text-purple-300 hover:from-purple-100 hover:to-indigo-100 dark:hover:from-purple-900/30 dark:hover:to-indigo-900/30 border border-purple-200/50 dark:border-purple-800/40'
              }`}
            >
              {isListening ? (
                <>
                  <MicOff className="h-3.5 w-3.5" />
                  <span>Stop Dictating</span>
                </>
              ) : (
                <>
                  <Mic className="h-3.5 w-3.5 text-purple-600 dark:text-purple-400 animate-bounce" />
                  <span>Dictate (Voice)</span>
                </>
              )}
            </button>
          )}
        </div>
        <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
          This is a safe space. Write out whatever is on your mind about your studies, mock tests, or expectations.
        </p>
        
        {speechError && (
          <div className="mb-3 flex items-center gap-2 rounded-xl bg-amber-50 dark:bg-amber-950/20 p-3 text-xs text-amber-700 dark:text-amber-400 ring-1 ring-amber-200 dark:ring-amber-900/30">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{speechError}</span>
          </div>
        )}

        <textarea
          id="journal"
          rows={6}
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          placeholder="I'm feeling really stressed about the upcoming mock test. I studied all night but I still feel like..."
          className="w-full resize-none rounded-2xl border border-slate-200/60 dark:border-slate-800/60 bg-white/50 dark:bg-slate-950/40 p-4 text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 shadow-sm backdrop-blur-sm transition-all focus:border-purple-300 dark:focus:border-purple-800 focus:outline-none focus:ring-4 focus:ring-purple-100/50 dark:focus:ring-purple-950/50"
          required
        />
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={!entry.trim() || isLoading}
          className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-slate-800 dark:bg-purple-600 px-6 py-3 font-medium text-white shadow-md transition-all hover:bg-slate-700 dark:hover:bg-purple-500 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-slate-200 dark:focus:ring-purple-900 disabled:opacity-50 disabled:hover:bg-slate-800 dark:disabled:hover:bg-purple-600 disabled:hover:shadow-md"
        >
          {isLoading ? (
            <>
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
              <span>Analyzing...</span>
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 transition-transform group-hover:scale-110 text-purple-300" />
              <span>Discover Insights</span>
            </>
          )}
        </button>
      </div>
    </motion.form>
  );
}
